import { Component } from '@angular/core';

@Component({
  selector: 'app-pomodoro',
  standalone: true,
  imports: [],
  templateUrl: './pomodoro.component.html',
  styleUrl: './pomodoro.component.scss',
})
export class PomodoroComponent {}
