export const environment = {
  production: false,
  apiUrl: 'https://us-central1-rts-24-c3dbb.cloudfunctions.net/api',
};
