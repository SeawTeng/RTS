export const environment = {
  production: true,
  apiUrl: 'https://us-central1-rts-24-c3dbb.cloudfunctions.net/api',
};
